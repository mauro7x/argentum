# [Argentum Online](https://mauro7x.github.io/argentum/)

Proyecto integrador de la matería **Taller de Programación I**, para la carrera **Ingeniería Informática** de la **Facultad de Ingeniería, Universidad de Buenos Aires.**

Accedé al proyecto [aquí](https://mauro7x.github.io/argentum/).
