#ifndef __ORIENTATION_H__
#define __ORIENTATION_H__

//-----------------------------------------------------------------------------

enum Orientation {
    UP_ORIENTATION,
    DOWN_ORIENTATION,
    LEFT_ORIENTATION,
    RIGHT_ORIENTATION,
    N_ORIENTATIONS
};

//-----------------------------------------------------------------------------

#endif  // __ORIENTATION_H__